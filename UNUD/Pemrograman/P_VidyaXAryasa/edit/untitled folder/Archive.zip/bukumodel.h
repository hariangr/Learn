
// Struct untuk Buku
struct BukuModel
{
    char id[3];
    char jenis[50];
    char judul[50];
};